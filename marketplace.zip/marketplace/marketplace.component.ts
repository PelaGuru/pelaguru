import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pelaguru-marketplace',
  templateUrl: './marketplace.component.html',
  styleUrls: ['./marketplace.component.scss'],
})
export class MarketplaceComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
